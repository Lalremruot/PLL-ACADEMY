import { NextRequest } from 'next/server';
import { verifySessionToken, SESSION_COOKIE_NAME } from '@/lib/session';
import { successResponse, errorResponse } from '@/utils/apiResponse';

export async function GET(req: NextRequest) {
  try {
    const token = req.cookies.get(SESSION_COOKIE_NAME)?.value;
    const session = verifySessionToken(token);
    if (!session) {
      return errorResponse('Not authenticated', 401);
    }
    return successResponse(
      { email: session.email, role: session.role, name: session.name },
      'Session active'
    );
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Session verification failed';
    return errorResponse(message, 500);
  }
}
