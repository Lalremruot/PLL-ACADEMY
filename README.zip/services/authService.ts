import { randomBytes, scryptSync, timingSafeEqual } from 'crypto';
import { connectToDatabase } from '@/lib/mongodb';
import { UserModel } from '@/models/User';
import { SubscriptionModel } from '@/models/Subscription';

export const KNOWN_GUARANTORS = [
  { name: 'Marcus Sterling', email: 'm.sterling@footballmail.com', role: 'parent' as const },
  { name: 'Benicio Bellingham', email: 'b.bellingham@pro-striker.com', role: 'parent' as const },
  { name: 'Christopher Kane', email: 'kane@synco-sports.com', role: 'parent' as const },
  { name: 'Greta Grealish', email: 'greta@grealish-sports.com', role: 'parent' as const },
  { name: 'Roman Cruyff', email: 'roman.c@cruyff-academy.com', role: 'parent' as const },
  { name: 'Academy Administrator', email: 'admin@footballacademy.com', role: 'admin' as const },
  { name: 'Academy Manager', email: 'manager@strikeracademy.edu', role: 'manager' as const },
];

/**
 * Demo credentials kept so the app stays testable. These are validated
 * server-side against the same password rules as every other account.
 */
export const DEMO_ACCOUNTS = [
  { email: 'admin@strikeracademy.edu', password: 'admin123', role: 'admin' as const, name: 'Academy Administrator' },
  { email: 'manager@strikeracademy.edu', password: 'manager123', role: 'manager' as const, name: 'Academy Manager' },
];

/** Shared passkey for all parent accounts in the demo. */
export const PARENT_PASSKEY = 'parent123';

const HASH_KEY_LENGTH = 64;

export function hashPassword(password: string): string {
  const salt = randomBytes(16);
  const hash = scryptSync(password, salt, HASH_KEY_LENGTH);
  return `${salt.toString('hex')}:${hash.toString('hex')}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const [saltHex, hashHex] = storedHash.split(':');
  if (!saltHex || !hashHex) {
    return false;
  }
  const salt = Buffer.from(saltHex, 'hex');
  const expected = Buffer.from(hashHex, 'hex');
  const actual = scryptSync(password, salt, expected.length);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

/**
 * Thrown when credentials or role are invalid. The login route maps this to a
 * 401; all other errors are treated as server faults (500).
 */
export class AuthenticationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AuthenticationError';
  }
}

const resolveDisplayName = (role: 'admin' | 'manager' | 'parent', matchName?: string): string => {
  if (matchName) {
    return matchName;
  }
  switch (role) {
    case 'admin':
      return 'Academy Administrator';
    case 'manager':
      return 'Academy Manager';
    case 'parent':
      return 'Parent Guarantor';
    default: {
      const _exhaustive: never = role;
      return _exhaustive;
    }
  }
};

/**
 * Registers a new admin/manager account with a hashed password.
 */
export async function createUserAccount(input: {
  email: string;
  role: 'admin' | 'manager';
  name?: string;
  password: string;
}) {
  const db = await connectToDatabase();
  const email = input.email.toLowerCase().trim();
  if (input.password.length < 6) {
    throw new Error('Password must be at least 6 characters.');
  }
  if (db) {
    const existing = await UserModel.findOne({ email });
    if (existing) {
      throw new Error(`${input.role === 'admin' ? 'An admin' : 'A manager'} with this email already exists.`);
    }
    const created = await UserModel.create({
      email,
      role: input.role,
      name: input.name?.trim() || resolveDisplayName(input.role),
      passwordHash: hashPassword(input.password),
    });
    return { email: created.email, role: created.role, name: created.name };
  }
  return { email, role: input.role, name: input.name?.trim() || resolveDisplayName(input.role) };
}

/**
 * Changes the password for an existing admin/manager account after verifying
 * the current password.
 */
export async function changeUserPassword(input: {
  email: string;
  currentPassword: string;
  newPassword: string;
}) {
  const db = await connectToDatabase();
  const email = input.email.toLowerCase().trim();
  if (input.newPassword.length < 6) {
    throw new Error('New password must be at least 6 characters.');
  }
  if (db) {
    const user = await UserModel.findOne({ email }).select('+passwordHash');
    if (!user) {
      throw new Error('Account not found.');
    }
    if (!user.passwordHash || !verifyPassword(input.currentPassword, user.passwordHash)) {
      throw new Error('The current password you entered is incorrect.');
    }
    user.passwordHash = hashPassword(input.newPassword);
    await user.save();
    return { email: user.email, role: user.role, name: user.name };
  }
  return { email, role: 'admin' as const, name: undefined };
}

/**
 * Lists admin and manager accounts without password hashes.
 */
export async function listStaffAccounts() {
  const db = await connectToDatabase();
  if (!db) {
    return DEMO_ACCOUNTS.map(({ password: _password, ...account }) => account);
  }
  const docs = await UserModel.find({ role: { $in: ['admin', 'manager'] } })
    .sort({ role: 1, email: 1 })
    .lean();
  const staff = docs.map((doc) => ({
    email: doc.email,
    role: doc.role as 'admin' | 'manager',
    name: doc.name,
  }));
  for (const demo of DEMO_ACCOUNTS) {
    if (!staff.some((s) => s.email.toLowerCase() === demo.email)) {
      staff.push({ email: demo.email, role: demo.role, name: demo.name });
    }
  }
  return staff;
}

/**
 * Server-side login: validates email + password + role and returns the session
 * user. Admin/manager accounts authenticate against hashed credentials stored
 * in MongoDB when it is reachable, otherwise they fall back to the in-memory
 * demo credentials so the app stays testable during DB/DNS outages. Real
 * accounts always take precedence when the database is available, so password
 * changes still take effect.
 */
export async function loginUser(email: string, role: 'admin' | 'manager' | 'parent', password: string) {
  const normalizedEmail = email.toLowerCase().trim();
  const db = await connectToDatabase();

  if (role === 'parent') {
    if (password !== PARENT_PASSKEY) {
      throw new AuthenticationError(
        `Incorrect password. Default parent passkey is ${PARENT_PASSKEY}`
      );
    }
    const knownParent = KNOWN_GUARANTORS.find(
      (g) => g.role === 'parent' && g.email.toLowerCase() === normalizedEmail
    );
    if (db) {
      const registered = await SubscriptionModel.exists({ parentEmail: normalizedEmail });
      if (!knownParent && !registered) {
        throw new AuthenticationError('This parent email is not registered in our student directory.');
      }
    } else if (!knownParent) {
      throw new AuthenticationError('This parent email is not registered in our student directory.');
    }
    return {
      email: normalizedEmail,
      role: 'parent' as const,
      name: knownParent?.name || resolveDisplayName('parent', knownParent?.name),
    };
  }

  const demo = DEMO_ACCOUNTS.find(
    (d) => d.email.toLowerCase() === normalizedEmail && d.role === role && d.password === password
  );

  if (db) {
    const user = await UserModel.findOne({ email: normalizedEmail }).select('+passwordHash');
    if (user) {
      if (!user.passwordHash || !verifyPassword(password, user.passwordHash)) {
        throw new AuthenticationError('Invalid email or password for this role.');
      }
      if (user.role !== role) {
        throw new AuthenticationError('This account does not have access to the selected role.');
      }
      return {
        email: user.email,
        role: user.role as 'admin' | 'manager',
        name: user.name,
      };
    }
    if (!demo) {
      throw new AuthenticationError('Invalid email or password for this role.');
    }
    const created = await UserModel.create({
      email: normalizedEmail,
      role: demo.role,
      name: demo.name,
      passwordHash: hashPassword(demo.password),
    });
    return {
      email: created.email,
      role: created.role as 'admin' | 'manager',
      name: created.name,
    };
  }

  if (!demo) {
    throw new AuthenticationError('Invalid email or password for this role.');
  }
  return {
    email: normalizedEmail,
    role: demo.role,
    name: demo.name,
  };
}
