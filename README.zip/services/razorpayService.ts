import crypto from 'node:crypto';
import Razorpay from 'razorpay';
import { connectToDatabase } from '@/lib/mongodb';
import { SettingsModel } from '@/models/Settings';
import { encryptSecret, decryptSecret } from '@/lib/crypto';
import { payInvoice } from '@/services/invoiceService';
import { settleSubscriptionCycle } from '@/services/subscriptionBillingService';

const CREDS_KEY = 'razorpay_credentials';

export interface RazorpayCredentials {
  keyId: string;
  keySecret: string;
  webhookSecret: string;
  mode: 'Live' | 'Test';
}

export interface RazorpayPublicCredentials {
  keyId: string;
  mode: 'Live' | 'Test';
  configured: boolean;
}

interface StoredRazorpayCredentials {
  keyId: string;
  encryptedKeySecret: string;
  encryptedWebhookSecret?: string;
  mode: 'Live' | 'Test';
}

let memoryRazorpayCredentials: StoredRazorpayCredentials | null = null;

async function getStoredCredentials(): Promise<StoredRazorpayCredentials | null> {
  const db = await connectToDatabase();
  if (db) {
    const doc = await SettingsModel.findOne({ key: CREDS_KEY }).lean();
    return (doc?.value as StoredRazorpayCredentials | undefined) ?? null;
  }
  return memoryRazorpayCredentials;
}

async function persistCredentials(creds: StoredRazorpayCredentials): Promise<void> {
  const db = await connectToDatabase();
  if (db) {
    await SettingsModel.findOneAndUpdate(
      { key: CREDS_KEY },
      { key: CREDS_KEY, value: creds },
      { upsert: true, new: true }
    );
    return;
  }
  memoryRazorpayCredentials = creds;
}

export async function getRazorpayPublicCredentials(): Promise<RazorpayPublicCredentials> {
  const stored = await getStoredCredentials();
  return {
    keyId: stored?.keyId ?? '',
    mode: stored?.mode ?? 'Test',
    configured: !!(stored && stored.encryptedKeySecret),
  };
}

export async function saveRazorpayCredentials(input: {
  keyId: string;
  keySecret?: string;
  webhookSecret?: string;
  mode?: 'Live' | 'Test';
}): Promise<RazorpayPublicCredentials> {
  const existing = await getStoredCredentials();
  const next: StoredRazorpayCredentials = {
    keyId: input.keyId?.trim() || existing?.keyId || '',
    encryptedKeySecret: input.keySecret ? encryptSecret(input.keySecret) : existing?.encryptedKeySecret ?? '',
    encryptedWebhookSecret: input.webhookSecret
      ? encryptSecret(input.webhookSecret)
      : existing?.encryptedWebhookSecret,
    mode: input.mode || existing?.mode || 'Test',
  };

  if (!next.keyId || !next.encryptedKeySecret) {
    throw new Error('Razorpay Key ID and Key Secret are required.');
  }

  await persistCredentials(next);
  return {
    keyId: next.keyId,
    mode: next.mode,
    configured: true,
  };
}

export async function getRazorpayCredentials(): Promise<RazorpayCredentials> {
  const stored = await getStoredCredentials();
  if (!stored || !stored.keyId || !stored.encryptedKeySecret) {
    throw new Error('Razorpay is not configured. Add credentials in Settings.');
  }
  return {
    keyId: stored.keyId,
    keySecret: decryptSecret(stored.encryptedKeySecret),
    webhookSecret: stored.encryptedWebhookSecret ? decryptSecret(stored.encryptedWebhookSecret) : '',
    mode: stored.mode ?? 'Test',
  };
}

function getRazorpayClient(creds: RazorpayCredentials): Razorpay {
  return new Razorpay({
    key_id: creds.keyId,
    key_secret: creds.keySecret,
  });
}

export interface RazorpayOrderResult {
  orderId: string;
  keyId: string;
  amount: number;
  currency: string;
}

export interface RazorpaySubscriptionOrderResult {
  orderId: string;
  keyId: string;
  amount: number;
  currency: string;
}

export async function createRazorpayOrder(input: {
  amount: number;
  currency?: string;
  receipt: string;
  notes?: Record<string, string>;
}): Promise<RazorpayOrderResult> {
  const creds = await getRazorpayCredentials();
  const client = getRazorpayClient(creds);
  const amount = Math.round(input.amount * 100);
  const order = await client.orders.create({
    amount,
    currency: input.currency || 'INR',
    receipt: input.receipt,
    notes: input.notes,
  });
  return {
    orderId: order.id,
    keyId: creds.keyId,
    amount,
    currency: order.currency || input.currency || 'INR',
  };
}

export async function createRazorpaySubscriptionOrder(input: {
  subscriptionId: string;
  amount: number;
  parentName?: string;
  parentEmail?: string;
}): Promise<RazorpaySubscriptionOrderResult> {
  const creds = await getRazorpayCredentials();
  const client = getRazorpayClient(creds);
  const amount = Math.round(input.amount * 100);
  const expireAt = Math.floor(Date.now() / 1000) + 10 * 365 * 24 * 3600;

  const params: any = {
    amount,
    currency: 'INR',
    receipt: `SUB-${input.subscriptionId}`,
    method: 'emandate',
    payment_capture: 1,
    frequency: { interval: 'monthly' },
    notes: { subscriptionId: input.subscriptionId, type: 'subscription' },
    token: {
      auth_type: 'netbanking',
      max_amount: Math.max(amount, 10000),
      expire_at: expireAt,
      notes: { subscriptionId: input.subscriptionId },
    },
    customer_details: {
      name: input.parentName || 'Academy Parent',
      email: input.parentEmail || '',
    },
  };

  const order = await client.orders.create(params);
  return {
    orderId: order.id,
    keyId: creds.keyId,
    amount,
    currency: order.currency || 'INR',
  };
}

export async function fetchRazorpayPaymentTokenId(paymentId: string): Promise<string | null> {
  const creds = await getRazorpayCredentials();
  const client = getRazorpayClient(creds);
  const payment = await client.payments.fetch(paymentId);
  return (payment as any).token_id || null;
}

export function verifyPaymentSignature(input: {
  orderId: string;
  paymentId: string;
  signature: string;
  keySecret: string;
}): boolean {
  const expected = crypto
    .createHmac('sha256', input.keySecret)
    .update(`${input.orderId}|${input.paymentId}`)
    .digest('hex');
  const expectedBuf = Buffer.from(expected, 'utf8');
  const receivedBuf = Buffer.from(input.signature, 'utf8');
  return expectedBuf.length === receivedBuf.length && crypto.timingSafeEqual(expectedBuf, receivedBuf);
}

export function verifyWebhookSignature(body: string, signature: string, webhookSecret: string): boolean {
  if (!webhookSecret || !signature) return false;
  const expected = crypto.createHmac('sha256', webhookSecret).update(body).digest('hex');
  const expectedBuf = Buffer.from(expected, 'utf8');
  const receivedBuf = Buffer.from(signature, 'utf8');
  return expectedBuf.length === receivedBuf.length && crypto.timingSafeEqual(expectedBuf, receivedBuf);
}

export async function confirmPaymentViaWebhook(bodyText: string, signature: string): Promise<boolean> {
  const creds = await getRazorpayCredentials();
  if (!verifyWebhookSignature(bodyText, signature, creds.webhookSecret)) {
    return false;
  }

  const event = JSON.parse(bodyText);
  if (event.event !== 'payment.captured') {
    return true;
  }

  const payment = event.payload?.payment?.entity;
  const orderId = payment?.order_id;
  let invoiceId = payment?.notes?.invoiceId;
  let subscriptionId = payment?.notes?.subscriptionId;

  if (!invoiceId && !subscriptionId && orderId) {
    try {
      const client = getRazorpayClient(creds);
      const order: any = await client.orders.fetch(orderId);
      subscriptionId = order?.notes?.subscriptionId;
      invoiceId = order?.notes?.invoiceId;
    } catch {
      // Order lookup is best-effort; fall through to invoice mapping.
    }
  }

  if (subscriptionId) {
    await settleSubscriptionCycle(subscriptionId, payment.id);
    return true;
  }

  if (invoiceId) {
    await payInvoice(invoiceId, payment.id);
  }

  return true;
}
