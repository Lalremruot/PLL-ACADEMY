import { getAllInvoices, createInvoice } from '@/services/invoiceService';
import { getAllSubscriptions, updateSubscription } from '@/services/subscriptionService';
import { Subscription } from '@/src/types';

function addMonths(dateStr: string, months: number): string {
  const d = new Date(`${dateStr}T00:00:00`);
  if (Number.isNaN(d.getTime())) {
    return new Date(Date.now() + months * 30 * 86400000).toISOString().split('T')[0];
  }
  d.setMonth(d.getMonth() + months);
  return d.toISOString().split('T')[0];
}

function monthKey(date: Date): string {
  return `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}`;
}

export async function settleSubscriptionCycle(
  subscriptionId: string,
  paymentId: string,
  tokenId?: string
): Promise<Subscription | null> {
  const subs = await getAllSubscriptions();
  const sub = subs.find((s) => s.id === subscriptionId);
  if (!sub) return null;

  const now = new Date();
  const invoiceId = `INV-${sub.id.replace('SUB-', '')}-${monthKey(now)}`;
  const invoices = await getAllInvoices();
  const existing = invoices.find((inv) => inv.id === invoiceId);

  if (!existing) {
    const monthName = now.toLocaleString('en-US', { month: 'long', year: 'numeric' });
    await createInvoice({
      id: invoiceId,
      studentName: sub.studentName,
      parentName: sub.parentName,
      parentEmail: sub.parentEmail,
      amount: sub.monthlyFee,
      courseName: sub.courseName,
      date: now.toISOString().split('T')[0],
      dueDate: now.toISOString().split('T')[0],
      status: 'Success',
      transactionId: paymentId,
      semester: monthName,
    });
  }

  const nextBillingDate = addMonths(sub.nextBillingDate, 1);
  const updated = await updateSubscription({
    ...sub,
    nextBillingDate,
    autoDebit: true,
    razorpayTokenId: tokenId || sub.razorpayTokenId,
  });

  return updated;
}
