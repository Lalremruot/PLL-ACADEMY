import { connectToDatabase } from '@/lib/mongodb';
import { SubscriptionModel } from '@/models/Subscription';
import { INITIAL_SUBSCRIPTIONS } from '@/src/seedData';
import { Subscription } from '@/src/types';

let memorySubscriptions: Subscription[] = [...INITIAL_SUBSCRIPTIONS];

export async function getAllSubscriptions(): Promise<Subscription[]> {
  const db = await connectToDatabase();
  if (db) {
    const count = await SubscriptionModel.countDocuments();
    if (count === 0) {
      await SubscriptionModel.insertMany(INITIAL_SUBSCRIPTIONS);
    }
    const docs = await SubscriptionModel.find({}).sort({ createdAt: -1 }).lean();
    return docs.map(doc => ({
      id: doc.id,
      studentName: doc.studentName,
      parentName: doc.parentName,
      parentEmail: doc.parentEmail,
      courseName: doc.courseName,
      status: doc.status as any,
      tier: doc.tier as any,
      monthlyFee: doc.monthlyFee,
      nextBillingDate: doc.nextBillingDate,
      batch: doc.batch,
      age: doc.age,
      height: doc.height,
      weight: doc.weight,
      aadhaar: doc.aadhaar,
      education: doc.education,
      familyDetails: doc.familyDetails,
      profilePic: doc.profilePic,
      autoDebit: doc.autoDebit,
      razorpayTokenId: doc.razorpayTokenId,
    }));
  }

  return memorySubscriptions;
}

export async function createSubscription(subData: Partial<Subscription>): Promise<Subscription> {
  const newSub: Subscription = {
    id: subData.id || `SUB-${Math.floor(1000 + Math.random() * 9000)}-${String.fromCharCode(65 + Math.floor(Math.random() * 26))}`,
    studentName: subData.studentName || 'New Athlete',
    parentName: subData.parentName || 'Guardian',
    parentEmail: subData.parentEmail || 'guardian@footballmail.com',
    courseName: subData.courseName || 'Pro Academy Program',
    status: subData.status || 'Active',
    tier: subData.tier || 'Standard',
    monthlyFee: subData.monthlyFee || 300,
    nextBillingDate: subData.nextBillingDate || new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
    batch: subData.batch || 'Under-15 Development Group',
    age: subData.age,
    height: subData.height,
    weight: subData.weight,
    aadhaar: subData.aadhaar,
    education: subData.education,
    familyDetails: subData.familyDetails,
    profilePic: subData.profilePic,
  };

  const db = await connectToDatabase();
  if (db) {
    await SubscriptionModel.create(newSub);
  } else {
    memorySubscriptions.unshift(newSub);
  }

  return newSub;
}

export async function updateSubscription(sub: Subscription): Promise<Subscription | null> {
  const db = await connectToDatabase();
  if (db) {
    const updated = await SubscriptionModel.findOneAndUpdate(
      { id: sub.id },
      { $set: sub },
      { new: true, upsert: true }
    ).lean();

    return {
      id: updated.id,
      studentName: updated.studentName,
      parentName: updated.parentName,
      parentEmail: updated.parentEmail,
      courseName: updated.courseName,
      status: updated.status as any,
      tier: updated.tier as any,
      monthlyFee: updated.monthlyFee,
      nextBillingDate: updated.nextBillingDate,
      batch: updated.batch,
      age: updated.age,
      height: updated.height,
      weight: updated.weight,
      aadhaar: updated.aadhaar,
      education: updated.education,
      familyDetails: updated.familyDetails,
      profilePic: updated.profilePic,
      autoDebit: updated.autoDebit,
      razorpayTokenId: updated.razorpayTokenId,
    };
  }

  const index = memorySubscriptions.findIndex(s => s.id === sub.id);
  if (index !== -1) {
    memorySubscriptions[index] = { ...sub };
  } else {
    memorySubscriptions.push(sub);
  }

  return sub;
}

export async function updateSubscriptionStatus(subId: string, status: 'Active' | 'Paused' | 'Canceled'): Promise<Subscription | null> {
  const db = await connectToDatabase();
  if (db) {
    const updated = await SubscriptionModel.findOneAndUpdate(
      { id: subId },
      { $set: { status } },
      { new: true }
    ).lean();

    if (!updated) return null;
    return {
      id: updated.id,
      studentName: updated.studentName,
      parentName: updated.parentName,
      parentEmail: updated.parentEmail,
      courseName: updated.courseName,
      status: updated.status as any,
      tier: updated.tier as any,
      monthlyFee: updated.monthlyFee,
      nextBillingDate: updated.nextBillingDate,
      batch: updated.batch,
      age: updated.age,
      height: updated.height,
      weight: updated.weight,
      aadhaar: updated.aadhaar,
      education: updated.education,
      familyDetails: updated.familyDetails,
      profilePic: updated.profilePic,
      autoDebit: updated.autoDebit,
      razorpayTokenId: updated.razorpayTokenId,
    };
  }

  const index = memorySubscriptions.findIndex(s => s.id === subId);
  if (index === -1) return null;

  memorySubscriptions[index] = {
    ...memorySubscriptions[index],
    status,
  };

  return memorySubscriptions[index];
}

export async function updateAllSubscriptions(subscriptions: Subscription[]): Promise<Subscription[]> {
  const db = await connectToDatabase();
  if (db) {
    await SubscriptionModel.deleteMany({});
    await SubscriptionModel.insertMany(subscriptions);
    return subscriptions;
  }

  memorySubscriptions = [...subscriptions];
  return memorySubscriptions;
}
